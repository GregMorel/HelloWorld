hello_world <- function(nom) {
  print(paste0("Hello, ", nom))
}